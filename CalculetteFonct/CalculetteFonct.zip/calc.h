#ifndef _H_CALC_
	#define _H_CALC_
	extern float calc_add(const float f1,const float f2);
	extern float calc_sub(const float f1,const float f2);
	extern float calc_abs(const float f1,const float f2);
	extern float calc_mult(const float f1,const float f2);
	extern float calc_div(const float f1,const float f2);
#endif
